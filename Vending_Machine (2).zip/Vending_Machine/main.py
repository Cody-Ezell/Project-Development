#########################################################################################################
# Programmer: Cody Ezell
# Date Created: 9/15/20
# File Name: Vending_Machinet.py
# Description: This program implements a vending machine. The user
#              shall make a selection from the menu, then the program
#              shall output that the machine will now vend that selection.
#              This program is stubbed for basic formatting purposes.
# Function List:
#   displayMenu - displays the menu for the vending machine
#   calculateAndDispenseBeverage - Filters the user's inputted choice,
#                                  then calls the getPayment function, and dispenses the beverage.
#   getPayment - requests payment from the user and calculates if user gave correct amount
#   main - main function of the program
# Global Variables
#   CANCELLED - used to indicate if user has pressed the cancel button to cancel transaction and exit
#########################################################################################################

from PIL import Image
import time
from playsound import playsound

# Global variables
CANCELLED = False    # used to indicate if user has pressed the cancel button to cancel transaction and exit
BEVERAGE_PRICE = 1

#####################################################################
# Function: displayMenu - displays the menu for the vending machine
#####################################################################
def displayMenu():
    print("""
    All beverages $1.00
    -------------------
    1. Coke 
    2. Sprite
    3. Root Beer
    4. Dr. Pepper
    5. Peach Sunkist
    6. Ginger Ale
    7. Mountain Dew
    8. Cream Soda
    9. Sparkling Water
    10. Water
    E. - CANCEL & EXIT
    """)

###################################################################################
# Function: calculateAndDispenseBeverage - Filters the user's inputted choice,
# then calls the calculate function and dispense function.
###################################################################################
def calculateAndDispenseBeverage(selection):
    if selection == '1':
        getPayment()
        coke = Image.open("Beverage Pictures/coke.png")
        print("DISPENSING BEVERAGE...")
        playsound("drinkDispense.mp3")
        coke.show()
        print("THANK YOU, COME AGAIN!")
    elif selection == '2':
        getPayment()
        sprite = Image.open("Beverage Pictures/sprite.png")
        print("DISPENSING BEVERAGE...")
        playsound("drinkDispense.mp3")
        sprite.show()
        print("THANK YOU, COME AGAIN!")
    elif selection == '3':
        getPayment()
        rootbeer = Image.open("Beverage Pictures/rootbeer.png")
        print("DISPENSING BEVERAGE...")
        playsound("drinkDispense.mp3")
        rootbeer.show()
        print("THANK YOU, COME AGAIN!")
    elif selection == '4':
        getPayment()
        drpepper = Image.open("Beverage Pictures/drpepper.png")
        print("DISPENSING BEVERAGE...")
        playsound("drinkDispense.mp3")
        drpepper.show()
        print("THANK YOU, COME AGAIN!")
    elif selection == '5':
        getPayment()
        peachsunkist = Image.open("Beverage Pictures/peachsunkist.png")
        print("DISPENSING BEVERAGE...")
        playsound("drinkDispense.mp3")
        peachsunkist.show()
        print("THANK YOU, COME AGAIN!")
    elif selection == '6':
        getPayment()
        gingerale = Image.open("Beverage Pictures/gingerale.png")
        print("DISPENSING BEVERAGE...")
        playsound("drinkDispense.mp3")
        gingerale.show()
        print("THANK YOU, COME AGAIN!")
    elif selection == '7':
        getPayment()
        mountaindew = Image.open("Beverage Pictures/mountaindew.png")
        print("DISPENSING BEVERAGE...")
        playsound("drinkDispense.mp3")
        mountaindew.show()
        print("THANK YOU, COME AGAIN!")
    elif selection == '8':
        getPayment()
        creamsoda = Image.open("Beverage Pictures/creamsoda.png")
        print("DISPENSING BEVERAGE...")
        playsound("drinkDispense.mp3")
        creamsoda.show()
        print("THANK YOU, COME AGAIN!")
    elif selection == '9':
        getPayment()
        sparklingwater = Image.open("Beverage Pictures/sparklingwater.png")
        print("DISPENSING BEVERAGE...")
        playsound("drinkDispense.mp3")
        sparklingwater.show()
        print("THANK YOU, COME AGAIN!")
    elif selection == '10':
        getPayment()
        water = Image.open("Beverage Pictures/water.png")
        print("DISPENSING BEVERAGE...")
        playsound("drinkDispense.mp3")
        water.show()
        print("THANK YOU, COME AGAIN!")
    elif selection == 'e' or selection == 'E':
        print("CANCELING TRANSACTION AND EXITING")
        global CANCELLED   # Global keyword allows you to modify the variable outside of the current scope.
        CANCELLED = True
    else:
        print("INCORRECT OR UNDEFINED SELECTION - TRY AGAIN")

###################################################################################
# Function: getPayment - requests the user to insert moneytary amount, and then
#           calculates if the user entered the right amount.  If no, it informs
#           the user how much is remaining before user can receive beverage
###################################################################################
def getPayment():
    sufficient_balance = False
    remaining_balance = BEVERAGE_PRICE
    change_due = 0.0

    # loops until user has given the correct amount ($1)it
    while (sufficient_balance != True):
        print(f"Please deposit ${remaining_balance}")
        amount_inserted = float(input("insert here --> $"))

        # determines if the amount the user entered is adequate enough
        if(float(amount_inserted) == remaining_balance):
            sufficient_balance = True
        elif(float(amount_inserted) < remaining_balance):
            sufficient_balance = False
            remaining_balance -= amount_inserted
        elif(float(amount_inserted) > remaining_balance):
            sufficient_balance = True
            change_due = amount_inserted - BEVERAGE_PRICE
            print(f"Change due: ${change_due}")

#####################################################################
# Function: main - main function of the program
#####################################################################
def main():
    # Displays the name of the vending machine
    print("\nBestest Most Wonderfulest Vending Machine")
    print("-----------------------------------------")

    # while loop that repeats the menu and ability for user to select a choice until cancelled by user.
    while not CANCELLED:
        displayMenu()
        selection = input("Make a selection (1-10): ")
        calculateAndDispenseBeverage(selection)


if __name__ == "__main__":
    main()